package cs5004.animator.model.transformation;

/** Enum that tells if a ResizeT is acting on the Base or Height of a Shape. */
public enum dimension {
  BASE,
  HEIGHT
}
